<body id="page-top">
    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="/pages">Imel</a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/pages/about">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="/pages/contact">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <style>
        @keyframes glitter {
            0% {
                opacity: 1;
            }

            50% {
                opacity: 0.5;
            }

            100% {
                opacity: 1;
            }
        }

        .glitter-effect {
            animation: glitter 1s infinite;
        }
    </style>

    <style>
        @keyframes glitter {
            0% {
                opacity: 0.7;
            }

            50% {
                opacity: 1;
            }

            100% {
                opacity: 0.7;
            }
        }

        .glitter-effect::before {
            content: "●";
            display: inline-block;
            color: #fff;
            /* Warna mutiara (putih) */
            animation: glitter 1s infinite;
        }
    </style>

    <style>
        @keyframes moveText {
            0% {
                transform: translateX(0);
            }

            50% {
                transform: translateX(10px);
            }

            100% {
                transform: translateX(0);
            }
        }

        .moving-text {
            display: inline-block;
            animation: moveText 2s infinite;
        }
    </style>

    <!-- About-->
    <section class="about-section text-center" id="about" style="background-color: #ff98b1; color: #000; padding: 50px 0; position: relative;">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8" style="font-family: 'Arial', sans-serif;">

                    <h2 class="mb-4" style="font-size: 2.5em; border-bottom: 2px solid #000; display: inline-block; padding-bottom: 10px; position: absolute; top: 0; left: 50%; transform: translateX(-50%);">
                        <span class="moving-text">HALO SEMUA</span>

                    </h2>
                    <p class="text-dark" style="text-align: justify; margin-top: 100px;"> <!-- Anda bisa menyesuaikan nilai margin-top sesuai kebutuhan -->
                        Seperti pepatah mengatakan tak kenal maka tak sayang, tak sayang maka tak cinta, terlalu sayang lalu ditinggalkan hihi. Halo semua! perkenalkan saya Imelda Rosa, biasa dipanggil Imel. Saya adalah seorang Mahasiswa semester 5 jurusan Manajemen Informatika Politeknik Negeri Sriwijaya. Saya berasal dari Kabupaten Musi Banyuasin yang merantau menuntut ilmu ke Palembang. Orang tua saya adalah motivasi dalam hidup saya. Saya sangat mencintai orang tua saya dan bercita-cita membuat mereka bangga.
                    </p>
                    <p class="text-dark" style="text-align: justify;">
                        Jurusan Manajemen informatika adalah jurusan yang sangat memberi saya peluang untuk saya ingin tulisannya berubah font mengenal dunia IT lebih dalam, karena banyak hal-hal baru yang saya pelajari. Semoga kedepannya saya bisa jadi programmer Aamiin.
                    </p>
                </div>
            </div>
        </div>
    </section>

    </p>
    </div>
    </div>
    </div>
    </section>

    </p>
    <div style="clear: both;"></div>
    </div>
    </div>
    </div>
    </section>


    </p>
    </div>
    </div>
    </div>
    </section>

    </div>
    </div>
    </div>
    </section>

    </p>
    </div>
    </div>
    </div>
    </section>

    </p>
    </div>
    </div>
    </div>
    </section>

    </p>
    </div>
    </div>
    </div>
    </section>

    </div>
    </div>
    </div>
    </section>

    </p>
    </div>
    </div>
    </div>
    </section>

    </p>
    </div>
    </div>
    </div>
    </section>

    </p>
    </div>
    </div>
    </div>
    </section>

    </div>
    </div>
    </div>
    </section>

    <!-- Riwayat Pendidikan-->
    <section class="projects-section bg-light" id="Riwayat Pendidikan">
        <div class="container px-4 px-lg-5">
            <!-- Featured Hobby Row-->
            <div class="row gx-0 mb-4 mb-lg-5 align-items-center">
                <div class="col-xl-8 col-lg-7">
                    <img class="img-fluid mb-3 mb-lg-0" src="https://i.ytimg.com/vi/RD5ITPMKg30/maxresdefault.jpg" alt="..." />
                </div>
                <div class="col-xl-4 col-lg-5">
                    <div class="featured-text text-center text-lg-left">
                        <div class="education-box">
                            <h4>SD NEGERI 1 EPIL</h4>

                        </div>
                        <div class="education-box">
                            <h4>SMP NEGERI 2 LAIS</h4>

                        </div>
                        <div class="education-box">
                            <h4>SMA NEGERI 2 SEKAYU</h4>

                        </div>
                        <p class="text-black-50 mb-0">Saat ini saya sedang menempuh pendidikan di Politeknik Negeri Sriwijaya. Saya berharap ilmu yang saya pelajari bisa bermanfaat bagi orang banyak kedepannya</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <style>
        .education-box {
            border: 2px solid #343a40;
            /* Warna garis kotak */
            padding: 10px;
            margin-bottom: 10px;
        }
    </style>

    </div>
    </div>
    </div>
    <div class="row gx-0 mb-5 mb-lg-0 justify-content-center" style="background-color: pink;">
        <div class="col-12">
            <div class="bg-black text-center h-100 project">
                <div class="d-flex h-100">
                    <div class="project-text w-100 my-auto text-center text-lg-left" style="color: black;">
                        <h4 class="text-white">HOBBY SAYA</h4>
                        <p class="mb-0 text-white-50">"Dunia adalah buku, dan mereka yang tidak bepergian hanya membaca satu halaman." - Saint Augustine</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <img class="img-fluid" src="https://cdn.pixabay.com/photo/2016/06/20/03/21/rainbow-1467988_1280.jpg" alt="..." style="transition: transform 0.3s ease-in-out;">
        </div>
        <div class="col-lg-6">
            <div class="bg-black text-center h-100 project" style="transition: background-color 0.3s ease-in-out;">
                <div class="d-flex h-100">
                    <div class="project-text w-100 my-auto text-center text-lg-left" style="color: black;">
                        <h4 class="text-white">kenapa saya hoby travelling?</h4>
                        <p class="mb-0 text-white-50">ketika hari libur dan tabungan sudah cukup saya selalu siap untuk memulai sebuah perjalanan yang sangat membuat saya bahagia. Travelling membuat saya mengerti bahwa hidup adalah perjalanan yang membuat kita harus tetap melangkah agar mencapai tujuan. </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
    </div>
    </div>
    </div>


    </div>
    </div>
    </div>
    </div>
    </div>