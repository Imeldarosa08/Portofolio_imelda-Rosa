<body id="page-top">
    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="/pages">Imelda</a>

            Menu
            <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/pages/about">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="/pages/contact">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Contact-->
    <section class="masthead contact-section bg-black">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5">
                <div class="col-md-4 mb-3 mb-md-0">
                    <div class="card py-4 h-100">
                        <div class="card-body text-center" style="border-radius: 50%; background-color: #f7d7c8; box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); transition: transform 0.3s ease-in-out;">

                            <!-- Konten card-body -->
                            <h2 class="mb-3">Hello!</h2>
                            <i class="fas fa-map-marked-alt text-primary mb-2"></i>
                            <h4 class="text-uppercase m-0">Contact US</h4>
                            <hr class="my-4 mx-auto" />
                            <div class="small text-black-50">Alamat :Dawas, Musi Banyuasin</div>
                            <div class="small text-black-50">Email : iamluckygirl@gmail.com</div>
                            <div class="small text-black-50">Phone : 082278234123</div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    </div>
    </div>
    </div>
    <div class="col-md-4 mb-3 mb-md-0">

        < </div>
    </div>
    </div>
    </div>
    <div class="social d-flex justify-content-center">
        <a class="mx-2" href="https://www.instagram.com/Immld_/"><i class="fab fa-instagram"></i></a>
        <a class="mx-2" href="https://github.com/Imelda08"><i class="fab fa-github"></i></a>
    </div>
    </div>
    </section>