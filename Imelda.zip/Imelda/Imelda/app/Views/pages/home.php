<body id="page-top">
    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="/pages">tentang Palembang</a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/pages/about">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="/pages/contact">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <header class="masthead">
        <style>
            .masthead {
                /* Ganti URL dengan path gambar bergerak yang ingin Anda gunakan */
                background-image: url('https://media2.giphy.com/media/xUNda62Nt0bm2iZzXO/giphy.gif?cid=ecf05e478o0u40ge6zxa6ycgv9v0unn2pjhc3vpamgxsdsgg&ep=v1_gifs_search&rid=giphy.gif&ct=g');
                /* Properti-properti tambahan untuk menyesuaikan latar belakang */
                background-size: cover;
                background-position: center;
                /* Pastikan konten di atas gambar untuk kejelasan */
                color: black;
                /* Ubah warna teks jika diperlukan */
            }

            .custom-btn {
                /* Properti tombol yang sudah ada */
            }
        </style>

        <!-- Konten lainnya dalam header -->
        <div class="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center">
            <div class="d-flex justify-content-center">
                <div class="text-center">


                    <!-- Tombol dengan Sudut-sudut Bulat di Sisi Kiri dan Kanan -->
                    <a class="custom-btn" href="/pages/about">HIDDEN GEM PALEMBANG</a>
                </div>
            </div>
        </div>
    </header>